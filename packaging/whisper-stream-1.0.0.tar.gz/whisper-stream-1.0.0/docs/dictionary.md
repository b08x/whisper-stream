claude:Claude
gemini:Gemini
qodo:Qodo
github:GitHub
api:API
